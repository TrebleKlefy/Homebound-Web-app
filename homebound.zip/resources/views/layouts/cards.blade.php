

<div class="container">
    <div class="row">
        <div class="r_card ">
            <div class="r_car">
                <div class="r_ca">

<div class="imagecontainer">
            <div class="r_card_header" role="img" style=" background: url('http://www.2oceansvibe.com/wp-content/uploads/2011/07/man4.jpg') 50% 0% no-repeat;" >   
            </div>
</div>
<div class="contentcontainer">
            <div class="r_card_content">
                <div class="adress">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                    V.K. Stujeske 6, Osijek 31000, Hrvatska
                </div>
                <div class="text_info">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione odio provident reiciendis, exercitationem ex quidem voluptatum quas minus id, ea ut, cupiditate sunt. Incidunt vitae nihil sapiente impedit temporibus, repellat!
                    <div class="text_info_shade"></div>
                </div>
            </div>
            <div class="price_info">
                <span class="price_w">Price:</span>
                <span class="price_v">€ 1 337</span>
            </div>
            <div class="r_card_footer">
                <div class="icon area">
                    <i class="fa fa-home" aria-hidden="true"></i>95m<sup>2</sup>
                </div>
                <div class="icon room">
                    <i class="fa fa-bed" aria-hidden="true"></i>4
                </div>
                <div class="icon bath">
                    <i class="fa fa-bath" aria-hidden="true"></i>1
                </div>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div class="r_card ">
        <div class="r_car">
            <div class="r_ca">

<div class="imagecontainer">
        <div class="r_card_header" role="img" style=" background: url('http://www.2oceansvibe.com/wp-content/uploads/2011/07/man4.jpg') 50% 0% no-repeat;" >   
        </div>
</div>
<div class="contentcontainer">
        <div class="r_card_content">
            <div class="adress">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                V.K. Stujeske 6, Osijek 31000, Hrvatska
            </div>
            <div class="text_info">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione odio provident reiciendis, exercitationem ex quidem voluptatum quas minus id, ea ut, cupiditate sunt. Incidunt vitae nihil sapiente impedit temporibus, repellat!
                <div class="text_info_shade"></div>
            </div>
        </div>
        <div class="price_info">
            <span class="price_w">Price:</span>
            <span class="price_v">€ 1 337</span>
        </div>
        <div class="r_card_footer">
            <div class="icon area">
                <i class="fa fa-home" aria-hidden="true"></i>95m<sup>2</sup>
            </div>
            <div class="icon room">
                <i class="fa fa-bed" aria-hidden="true"></i>4
            </div>
            <div class="icon bath">
                <i class="fa fa-bath" aria-hidden="true"></i>1
            </div>
        </div>
    </div>
    </div>
</div>
</div>



<div class="r_card ">
    <div class="r_car">
        <div class="r_ca">

<div class="imagecontainer">
    <div class="r_card_header" role="img" style=" background: url('http://www.2oceansvibe.com/wp-content/uploads/2011/07/man4.jpg') 50% 0% no-repeat;" >   
    </div>
</div>
<div class="contentcontainer">
    <div class="r_card_content">
        <div class="adress">
            <i class="fa fa-map-marker" aria-hidden="true"></i>
            V.K. Stujeske 6, Osijek 31000, Hrvatska
        </div>
        <div class="text_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione odio provident reiciendis, exercitationem ex quidem voluptatum quas minus id, ea ut, cupiditate sunt. Incidunt vitae nihil sapiente impedit temporibus, repellat!
            <div class="text_info_shade"></div>
        </div>
    </div>
    <div class="price_info">
        <span class="price_w">Price:</span>
        <span class="price_v">€ 1 337</span>
    </div>
    <div class="r_card_footer">
        <div class="icon area">
            <i class="fa fa-home" aria-hidden="true"></i>95m<sup>2</sup>
        </div>
        <div class="icon room">
            <i class="fa fa-bed" aria-hidden="true"></i>4
        </div>
        <div class="icon bath">
            <i class="fa fa-bath" aria-hidden="true"></i>1
        </div>
    </div>
</div>
</div>
</div>
</div>









<div class="r_card ">
    <div class="r_car">
        <div class="r_ca">

<div class="imagecontainer">
    <div class="r_card_header" role="img" style=" background: url('http://www.2oceansvibe.com/wp-content/uploads/2011/07/man4.jpg') 50% 0% no-repeat;" >   
    </div>
</div>
<div class="contentcontainer">
    <div class="r_card_content">
        <div class="adress">
            <i class="fa fa-map-marker" aria-hidden="true"></i>
            V.K. Stujeske 6, Osijek 31000, Hrvatska
        </div>
        <div class="text_info">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione odio provident reiciendis, exercitationem ex quidem voluptatum quas minus id, ea ut, cupiditate sunt. Incidunt vitae nihil sapiente impedit temporibus, repellat!
            <div class="text_info_shade"></div>
        </div>
    </div>
    <div class="price_info">
        <span class="price_w">Price:</span>
        <span class="price_v">€ 1 337</span>
    </div>
    <div class="r_card_footer">
        <div class="icon area">
            <i class="fa fa-home" aria-hidden="true"></i>95m<sup>2</sup>
        </div>
        <div class="icon room">
            <i class="fa fa-bed" aria-hidden="true"></i>4
        </div>
        <div class="icon bath">
            <i class="fa fa-bath" aria-hidden="true"></i>1
        </div>
    </div>
</div>
</div>
</div>
</div>
    </div>
</div>

<script>
    $(document).ready(function(){

    $('.r_card').click(function(){
        $('.text_info').toggleClass('active');
        $('.text_info_shade').toggleClass('active_shade');
    });

});
</script>