

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('css'); ?>


 <!--     Fonts and icons     -->
 <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
 <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
 <!-- Nucleo Icons -->
 <!-- CSS Just for demo purpose, don't include it in your project -->
 <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
 <link href="<?php echo e(asset('css/black-dashboard.css?v=1.0.0')); ?>" rel="stylesheet">
 <link href="<?php echo e(asset('css/nucleo-icons.css')); ?>" rel="stylesheet">
 <?php $__env->stopSection(); ?>



 <div class="wrapper" >
   
     
    
    <div class="main-panel">
   
      <div class="content editcontent ">
        <div class="row py-4s">
          
          <div class="col-12">
            <div class="card card-user">
              <div class="card-body">
                <p class="card-text">
                  <div class="author">
                    <div class="block block-one"></div>
                    <div class="block block-two"></div>
                    <div class="block block-three"></div>
                    <div class="block block-four"></div>
                    <a href="javascript:void(0)">


                        


                      <?php if($user->profile_photo != null): ?>
                      <img  src="/uploads/images/<?php echo e($user->profile_photo); ?>"  class="avatar">                 
                        <?php else: ?>
                        <img src="https://demos.creative-tim.com/argon-dashboard/assets/img/theme/team-4.jpg" class="avatar">
                        <?php endif; ?>


                    <h5 class="title"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5>
                    </a>
                    <p class="description">
                      Ceo/Co-Founder
                    </p>
                    <div class="card-header text-center border-0 pt-8 pt-md-4 pb-0  ">
                    
                        <div class="d-flex justify-content-center pta-2"> 
                          <button href="#" id="previewBtn" class="btn btn-sm btn-infos mr-4" style="">Contact</button>
                          <button href="#" id="uploadBtn" class="btn btn-sm btn-default float-right">Make Report</button>
                        </div>
                      </div>
                  </div>
                </p>
                <div class="card-description text-center">
                  Do not be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                </div>
              </div>
              <div class="card-footer">
                <div class="button-container">
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                    <i class="fab fa-facebook"></i>
                  </button>
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                    <i class="fab fa-twitter"></i>
                  </button>
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                    <i class="fab fa-google-plus"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     
    </div>
  </div>
  
 



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\PhpstormProjects\homebound\resources\views/admin/show_profile.blade.php ENDPATH**/ ?>