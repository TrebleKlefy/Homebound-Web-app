

<?php $__env->startSection('content'); ?>
<?php $__env->startSection('css'); ?>

 <?php $__env->stopSection(); ?>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.min.css">


      
        <div class="row">
          <div class="col-md-8">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger"> 
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
                <?php endif; ?>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success pb-2">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                <?php endif; ?>
            <div class="card">
              <div class="card-header pt-2">
                <h5 class="title">Edit Profile</h5>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12 text-center">
                      <div id="upload-demo"></div>
                  </div>
                    
                      
                      
                      <div class="col-12 text-right">
                       
                     
                        <div class="d-flex justify-content-center "> 
                      <div class="pr-1">
                          <div class="fileUpload  ">
                              <input type="file" id="upload" class="upload">
                              <label for="file" class="pt-1 ">Choose an Image</label>
                          </div>
                      </div> 
                          <button href="#" id="uploadBtn" class="btn btn-sm btn-default float-right upload-result ">Upload Image</button>
                        </div>
                      </div>
                      <div class="d-flex  col-md-12 justify-content-center pb-3 "> 
                        
                          
                         
                          
                          
                      </div>
                    
              </div>
                <form action="/profile/<?php echo e($user->id); ?>" method="post">
              
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-5 pr-md-1">
                      <div class="form-group">
                        <label>Company (disabled)</label>
                        <input type="text" class="form-control" disabled="" placeholder="Company" value="Creative Code Inc.">
                      </div>
                    </div>
                    <div class="col-md-3 px-md-1">
                      <div class="form-group">
                        <label>Gender</label>
                      <input type="text" class="form-control" placeholder="Gender" name="gender" value="<?php echo e($user->gender); ?>" >
                      </div>
                    </div>
                    <div class="col-md-4 pl-md-1">
                      <div class="form-group">
                        <label for="exampleInputEmail1">TRN</label>
                        <input type="text" class="form-control"  placeholder="12345" name="trn" value="<?php echo e($user->trn); ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-md-1">
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo e($user->first_name); ?>" >
                      </div>
                    </div>
                    <div class="col-md-6 pl-md-1">
                      <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" name="last_name"  placeholder="Last Name" value="<?php echo e($user->last_name); ?>" >
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" placeholder="Street Line"  name="streetline" value="<?php echo e($user->address->streetline); ?>" >
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4 pr-md-1">
                      <div class="form-group">
                        <label>City</label>
                        <input type="text" class="form-control"  name="city" placeholder="City" value="<?php echo e($user->address->city); ?>">
                      </div>
                    </div>
                    <div class="col-md-4 px-md-1">
                      <div class="form-group">
                        <label>Country</label>
                        <input type="text" class="form-control" placeholder="Country"  name="country" value="<?php echo e($user->address->country); ?>">
                      </div>
                    </div>
                    <div class="col-md-4 pl-md-1">
                      <div class="form-group">
                        <label>Postal</label>
                        <input type="text" class="form-control" name="postOffice" placeholder="Postal" value="<?php echo e($user->address->postOffice); ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-md-1">
                      <div class="form-group">
                        <label>Phone number</label>
                        <input type="text" class="form-control"  name="primary_number"  placeholder="(876) 393-5612" value="<?php echo e($user->contacts->primary_number); ?>">
                      </div>
                    </div>
                    <div class="col-md-6 px-md-1">
                      <div class="form-group">
                        <label>Alternative Number</label>
                        <input type="text" class="form-control" name="secondary_number" placeholder="(876) 393-5612" value="<?php echo e($user->contacts->secondary_number); ?>" >
                      </div>
                    </div>
                   
                  </div>
                  <div class="row">
                    <div class="col-md-8">
                      <div class="form-group">
                        <label>About Me</label>
                        <textarea rows="4" cols="80" class="form-control" placeholder="Here can be your description" value="Mike">Lamborghini Mercy, Your chick she so thirsty, I'm in that two seat Lambo.</textarea>
                      </div>
                    </div>
                  </div>
                
              </div>
              <div class="card-footer">
                <button type="submit" class="btn btn-fill btn-primary">Save</button>
              </div>
            </form>
            </div>
           
          </div>
          <div class="col-md-4">
            <div class="card card-user">
              <div class="card-body">
                <p class="card-text">
                  <div class="author">
                    <div class="block block-one"></div>
                    <div class="block block-two"></div>
                    <div class="block block-three"></div>
                    <div class="block block-four"></div>
                    <a href="javascript:void(0)">
                      <?php if($user->profile_photo != null): ?>
                      <img  src="/uploads/images/<?php echo e($user->profile_photo); ?>"  class="avatar">                 
                        <?php else: ?>
                        <img src="https://demos.creative-tim.com/argon-dashboard/assets/img/theme/team-4.jpg" class="avatar">
                        <?php endif; ?>
                     <h5 class="title"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h5>
                    </a>
                    <p class="description">
                      Ceo/Co-Founder
                    </p>
                  </div>
                </p>
                <div class="card-description">
                  Do not be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                </div>
              </div>
              <div class="card-footer">
                <div class="button-container">
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-facebook">
                    <i class="fab fa-facebook"></i>
                  </button>
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-twitter">
                    <i class="fab fa-twitter"></i>
                  </button>
                  <button href="javascript:void(0)" class="btn btn-icon btn-round btn-google">
                    <i class="fab fa-google-plus"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
    
    
   
 
 




   
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.js"></script>
   
  
   
 
   <script>
 
 
 $.ajaxSetup({
 headers: {
     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
 }
 });
 
 
 // 
 // $('.preview').show().attr('src',1600246527.jpeg);  
 $uploadCrop = $('#upload-demo').croppie({
     enableExif: true,
     viewport: {
         width: 200,
         height: 200,
         type: 'circle'
     },
     boundary: {
         width: 200,
         height: 200
     }
 });
 
 
 $('#upload').on('change', function () { 
   var reader = new FileReader();
     reader.onload = function (e) {
       $uploadCrop.croppie('bind', {
         url: e.target.result
       }).then(function(){
         console.log('jQuery bind complete');
       });
     }
     reader.readAsDataURL(this.files[0]);
 });
 
 
 $('.upload-result').on('click', function (ev) {
     // ev.preventDefault();
   $uploadCrop.croppie('result', {
     type: 'canvas',
     size: 'viewport'
   }).then(function (resp) {
     $.ajax({
       url: "/profile/storeimage",
       type: "POST",
       data: {"image":resp},
       success: function (data) {
                 $('.card-profile')[0].reset();
         html = '<img src="' + resp + '" />';
         $("#upload-demo-i").html(html);
       }
     });
   });
 });
  </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\PhpstormProjects\homebound\resources\views/admin/editprofile.blade.php ENDPATH**/ ?>