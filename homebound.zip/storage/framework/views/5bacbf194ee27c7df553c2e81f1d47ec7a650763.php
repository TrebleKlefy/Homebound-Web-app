<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Register</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="colorlib.com">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/material-design-iconic-font.css')); ?>" >
		<!-- STYLE CSS -->
		<link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">
       
        <script src="<?php echo e(asset('js/jquery.steps.js')); ?>" defer></script>
    	<script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
   
 
		
	</head>
	<body>
        <div class="wrapper">
            <form id="wizard"  method="POST" action="<?php echo e(route('register')); ?>">
              <?php echo csrf_field(); ?>
         
        		<!-- SECTION 1 -->
                <h2></h2>
                <section>
                    <div class="inner flex">
						<div class="image-holder">
							<img src="../img/apartment.jpg" alt="">
						</div>
						<div class="form-content reg" >
							<div class="form-header ">
								<h3>Registration</h3>
							</div>
							<p>Please fill with your details</p>
							<div class="form-row">
								<div class="form-holder">
                                    <input id="firstname" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="First Name">
								</div>
								<div class="form-holder">
                                    <input id="lastname" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="last_name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus  placeholder="Last Name">
								</div>
							</div>
							<div class="form-row">
								<div class="form-holder">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"  placeholder="Email">
								</div>
								<div class="form-holder">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password"  placeholder="Password">
								</div>
							</div>
							<div class="form-row">
								<div class="form-holder">
                                    <input id="confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password"  placeholder="Confirm password">
                                    <label id="error" style='font-size:10px; color:red;'></label>
								</div>
								<div class="form-holder" style="align-self: flex-end; transform: translateY(4px);">
									
									  
									<div class="checkbox-tick">
										<label class="male">
										
											<input type="radio" name="gender" value="male" checked> Male<br>
							
											<span class="checkmark"></span>
										</label>
										<label class="female">
											<input type="radio" name="gender" value="female"> Female<br>
											<span class="checkmark"></span>
										</label>
									</div>
								</div>
							</div>
							
						</div>
					</div>
                </section>

				<!-- SECTION 2 -->
                <h2></h2>
                <section>
                    <div class="inner">
						<div class="image-holder">
							<img src="../img/skyscraper.jpg" alt="">
						</div>
						<div class="form-content reg">
							<div class="form-header">
								<h3>Registration</h3>
							</div>
							<p>Please fill with additional info</p>
							<div class="form-row">
								<div class="form-holder w-100">
                                    <input id="streetline" type="text" class="form-control <?php $__errorArgs = ['streetline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="streetline" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus  placeholder="Street Line">
								</div>
							</div>
							<div class="form-row">
								<div class="form-holder">
                                    <input id="city" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus  placeholder="City">
								</div>
								<div class="form-holder">
                                    <input id="postoffice" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="postOffice" value="<?php echo e(old('postoffice')); ?>" required autocomplete="postoffice" autofocus  placeholder="Post Office">
								</div>
							</div>

							<div class="form-row">
								<div class="select">
									<div class="form-holder">
                                        <input id="country" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country" value="<?php echo e(old('country')); ?>" required autocomplete="Country" autofocus  placeholder="Country">
									</div>
									
								</div>
								<div class="form-holder">
                                    <input id="trn" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="trn" value="<?php echo e(old('trn')); ?>" required autocomplete="TRN" autofocus  placeholder="TRN">
                                </div>
							</div>
						</div>
					</div>
                </section>

                <!-- SECTION 3 -->
                <h2></h2>
                <section>
                    <div class="inner">
						<div class="image-holder">
							<img src="../img/city.jpg" alt="">
						</div>
						<div class="form-content reg">
							<div class="form-header">
								<h3>Registration</h3>
							</div>
							<p>Send an optional message</p>
							<div class="form-row">
								<div class="form-holder w-100">
                                   
                                    <input id="primary_number" type="text" class="form-control <?php $__errorArgs = ['PhoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="primary_number" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus  placeholder="Phone Number">
								</div>
							</div>
							<div class="form-row">
								<div class="form-holder">
                                    <input id="secondary_number" type="text" class="form-control <?php $__errorArgs = ['PhoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="secondary_number" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus  placeholder="Alternative Phone Number">
									
								</div>
								<div class="form-holder">
									<input type="text" name="pos" placeholder="postOffice" class="form-control" required>
								</div>
							</div>
							<div class="checkbox-circle mt-24">
								<label>
									<input type="checkbox" checked >  Please accept <a href="#">terms and conditions ?</a>
									<span class="checkmark"></span>
								</label>
								
                            </div>
							</div>
						</div>
					</div>
                </section>

            </form>
		</div> 

    
    <Script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"> </Script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>

		<!-- JQUERY STEP -->
		
		<!-- Template created and distributed by Colorlib -->
</body>
</html><?php /**PATH C:\Users\ASUS\PhpstormProjects\homebound\resources\views/auth/register.blade.php ENDPATH**/ ?>